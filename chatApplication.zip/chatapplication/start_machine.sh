#!/bin/bash

# Activate conda environment
CONDA_ENV_NAME="machine"
source ~/miniconda3/etc/profile.d/conda.sh
conda activate $CONDA_ENV_NAME

# Navigate to your Django project directory
DJANGO_PROJECT_DIR="D:\DjangoProject\machine\project\machine"
cd $DJANGO_PROJECT_DIR

# Run the Django development server
python manage.py runserver
